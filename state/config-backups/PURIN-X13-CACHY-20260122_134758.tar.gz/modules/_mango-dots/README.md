For potential mangoWC experiment
