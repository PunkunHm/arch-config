For KDE experiment

Mostly to get things done, but in similar manner/imagery to the original dots
