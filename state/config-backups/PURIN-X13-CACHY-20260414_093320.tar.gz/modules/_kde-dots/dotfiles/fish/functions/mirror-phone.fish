function mirror-phone --wraps='scrcpy --tcpip' --description 'alias mirror-phone=scrcpy --tcpip'
    scrcpy --tcpip $argv
end
