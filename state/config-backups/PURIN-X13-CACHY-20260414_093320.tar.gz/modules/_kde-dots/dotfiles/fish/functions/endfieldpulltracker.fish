function endfieldpulltracker
    set log_path (find "$HOME/.steam/steam/steamapps/compatdata" -name "HGWebview.log" -path "*/Gryphline/Endfield/*" | head -n 1)

    if test -f "$log_path"
        grep -oP 'WebPortal url: \Khttps://\S+' "$log_path" | tail -1 | wl-copy
        echo "Token copied to clipboard!"
    else
        echo "Log file not found. Open Headhunt history in-game first."
    end
end
