function fish_greeting
    fastfetch
end

if status is-interactive
    # Commands to run in interactive sessions can go here
end

# Add Flutter to PATH
fish_add_path $HOME/Dev/flutter/bin

# Set Chrome executable for Flutter web development
set -gx CHROME_EXECUTABLE /usr/bin/google-chrome-stable

# Helix editor alias
# alias hx helix
