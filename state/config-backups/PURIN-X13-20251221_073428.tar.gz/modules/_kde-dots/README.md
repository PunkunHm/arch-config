For potential KDE experiment
